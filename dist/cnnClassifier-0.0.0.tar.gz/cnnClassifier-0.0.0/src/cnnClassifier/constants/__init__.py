from pathlib import Path


CONFIG_PATH_FILE= Path("config/config.yaml")
PARAMS_FILE_PATH= Path("params.yaml")